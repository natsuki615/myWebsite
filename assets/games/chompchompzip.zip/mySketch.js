let tailArr = [];
let lenTailArr = 20;
class TailDot {
	constructor(x, y, size, alpha){
		this.x = x;
		this.y = y;
		this.size = size;
		this.alpha = alpha;
	}
	update() {
    this.alpha -= 5; 
    this.size -= 0.5; 
  }
	display() {
    noStroke();
    fill(255, 255, 255, this.alpha); 
    circle(this.x, this.y, this.size);
  }
	removeDot(arr){
		shorten(arr);
		this.size -= 1;
	}
}

function addDot(arr, x, y) {
  let dot = new TailDot(x, y, 15, 255); 
  arr.push(dot); 
  if (arr.length > lenTailArr) {
    arr.shift();
  }
}

function drawTails(side, x, y) {
  let tailX;
  if (side == "Left") {
    tailX = x - 200 + 50 * sin(frameCount * 0.05);
  } 
	else if (side == "Right") {
    tailX = x + 200 - 50 * sin(frameCount * 0.05);
  }
  let tailY = 30 * sin(frameCount * 0.5) + (y + 45); 
  addDot(tailArr, tailX, tailY);
  for (let i = 0; i < tailArr.length; i++) {
    tailArr[i].update(); 
    tailArr[i].display(); 
  }
}

//=============================DRAW BLOOD ==============================
let bloodArr = [];
let lenBloodArr = 20;
class Blood {
	constructor(x, y, size, alpha){		
		this.x = x;
		this.y = y;
		this.size = size;
		this.alpha = alpha;
		this.vel = p5.Vector.random2D().mult(random(2, 5));
	}
	update() {
    this.x += this.vel.x;
    this.y += this.vel.y;
    this.alpha -= 5;
    this.size -= 0.1;
  }
	display() {
    noStroke();
    fill(222, 81, 16, this.alpha); 
    circle(this.x, this.y, this.size);
  }
	removeDot(arr){
		return this.alpha <= 0 || this.size <= 0;
	}
}

function addDrop(arr, x, y) {
  let size = random(5, 20); 
  let alpha = random(155,255); 
  arr.push(new Blood(random(x-50,x+50), random(y-60,y+60), size, alpha));
}

let myWebcam;
let myHandTracker;
let hands = [];
let puppets = [];
let trackerOptions = {
	maxHands: 2,
	flipHorizontal: true
};
let webcamAlpha = 0;

let leftHealth = 255;
let rightHealth = 255;
let from = 'green';
let to = 'red';
let isChomped0 = false;
let isChomped1 = false;
let font;

// let accessories = ["hat", "necklace", "bodychain", "mustache"];
// let acce = random(accessories);
// print(acce);

let first = ["ar", "pho", "tra", "hur", "oo"];
let middle = ["lat", "kac", "sil", "ruv"];
let last = ["ia", "ee", "do", "ner"];
let name = [];
//draw plants in the front 
let frontColors = ["#79a832", "#90c462", "#b9d48e", "#688240"];
let colorList = [];
let plantX;
let plantTop;
let plantBottom;
let plantMid;
let pXList = [];
let pTopList = [];
let pBotList = [];
let pMidList = [];
let num;
//draw plants in the back
let backColors = ["#516666", "#61786d", "#36664f", "#496873"];
let colorList1 = [];
let plantX1;
let plantTop1;
let plantBottom1;
let plantMid1;
let pXList1 = [];
let pTopList1 = [];
let pBotList1 = [];
let pMidList1 = [];
let num1;

let isDead0 = false;
let isDead1 = false;

//----------------------------
function setup() {
	createCanvas(640, 480);
	initializeWebcamAndHandTracker();
	
	let ranF1 = random(first);
	let ranM1 = random(middle);
	let ranL1 = random(last);
	let ranF2 = random(first);
	let ranM2 = random(middle);
	let ranL2 = random(last);
	let name1 = ranF1 + ranM1 + ranL1;
	let name2 = ranF2 + ranM2 + ranL2;
	name = [name1, name2];
	
	num = random(5,7);
	for (let i=0; i<num; i++){
		let fCol = random(frontColors);
		plantX = random(0, 640);
		plantTop = random(320, 410);
		plantBottom = random(455, 475);
		plantMid = (plantTop+plantBottom)/2;
		append(colorList, fCol);
		append(pXList, plantX);
		append(pTopList, plantTop);
		append(pBotList, plantBottom);
		append(pMidList, plantMid);
	}
	
	num1 = random(5,7);
	for (let i=0; i<num1; i++){
		let fCol = random(backColors);
		plantX1 = random(0, 640);
		plantTop1 = random(120, 280);
		plantBottom1 = random(430, 450);
		plantMid1 = (plantTop1+plantBottom1)/2;
		append(colorList1, fCol);
		append(pXList1, plantX1);
		append(pTopList1, plantTop1);
		append(pBotList1, plantBottom1);
		append(pMidList1, plantMid1);
	}
}

//----------------------------
function draw() {
	background(color(119, 146, 209));
	drawWebcamVideo();
	// drawAllHandPoints(); 
	drawBackground();
	//back plants
	for (let i=0; i<colorList1.length; i++){
		drawBackPlant(colorList1[i], pXList1[i], 
									 pTopList1[i], pBotList1[i], pMidList1[i]);
	}
	drawPac();
	//front plants
	for (let i=0; i<colorList.length; i++){
		drawFrontPlant(colorList[i], pXList[i], 
									 pTopList[i], pBotList[i], pMidList[i]);
	}
	//blood
	for (let i = bloodArr.length - 1; i >= 0; i--) {
    bloodArr[i].update();
    bloodArr[i].display();
    if (bloodArr[i].removeDot()) {
      bloodArr.splice(i, 1);
    }
  }
	healthBar();
	damage();
}

//----------------------------
function drawAllHandPoints() {
	// Draw all the tracked hand points
	noStroke();
	fill('red');
	textSize(16);
	textAlign(CENTER);

	if (hands.length == 0) {
		// If there are no hands visible
		text("Present hand(s) to camera", width / 2, 30);

	} else {
		for (let i = 0; i < hands.length; i++) {
			let hand = hands[i];
			let keypoints = hand.keypoints; // also available: keypoints3D
			for (let j = 0; j < keypoints.length; j++) {
				let aKeypoint = keypoints[j];
				circle(aKeypoint.x, aKeypoint.y, 10);
				textSize(11);
				text(j, aKeypoint.x, aKeypoint.y - 7);
			}
			let whichHand = hand.handedness;
			let wx = keypoints[WRIST].x;
			let wy = keypoints[WRIST].y;
			textSize(20);
			text(whichHand, wx, wy - 50);
		}
	}
}

function drawBackground(){
  noStroke();
  colors = ["#5e7bbf", "#3450ad"]; //'##25618a', '##254a8a'
  yPos = [200, 325]; 

	for (let i=0; i < colors.length; i++) {
		fill(colors[i]);
		noStroke();
		beginShape();
		curveVertex(0, height); 
		curveVertex(0, yPos[i]);
		for (let x = 0; x <= width; x += 10) {
			let y = yPos[i] - noise(x * 0.001 + (millis()/1000), i * 0.5) * 130;
			curveVertex(x, y);
		}
		curveVertex(width, yPos[i]);
		curveVertex(width, height); 
		endShape(CLOSE);
		}
	push();
	fill("#d4cfbc");
	beginShape();
	bezier(0,450, 10,430, (width/3)-50,430, width/3,450);
	bezier(width/3,450, width/2,470, (width/3)-10,470, 2*width/3,450);
	bezier(2*width/3,450, (2*width/3)+80,430, (2*width/3)-10,430, width,450);
	endShape();
	rect(0, 450, width, 30);
	pop();
}

function drawFrontPlant(fCol, x, plantTop, plantBottom, plantMid){
	fill(fCol);
	beginShape();
	bezier(x,plantTop, x+30,plantTop, x-20,plantMid, x+10,plantMid);
	bezier(x+10,plantMid, x+30,plantMid, x+20,plantMid, x,plantBottom);
	bezier(x,plantBottom, x,plantMid+10, x,plantMid, x-20,plantMid);
	endShape();
}

function drawBackPlant(fCol, x, plantTop, plantBottom, plantMid){
	fill(fCol);
	beginShape();
	bezier(x,plantTop, x+15,plantTop+10, x+20,plantBottom-10, x,plantBottom);
	bezier(x,plantBottom, x-20,plantBottom-10, x-10,plantTop+10, x,plantTop);
	endShape();
}

function drawName(side, x, y){
	textSize(16);
	textFont(font);
	textAlign(CENTER, CENTER);
	if (side == "Left"){
		text(name[0], x-30, y-80);
	}
	else{
		text(name[1], x+30, y-80);
	}
}

function endGame(side) {
	noLoop();
	background(104, 155, 189, 100); 
  fill(255); 
	textFont(font);
  textSize(36);
	textAlign(CENTER, CENTER);
	if (side == "Left"){
		push();
		fill(color(57, 79, 125, 200));
		rect(0, 0, width, height);
		pop();
		push();
		textSize(72);
		text("WINNER", width/2, height/3);
		pop();
		text(name[0], width/2, height/2);
	}
  else{
		push();
		fill(color(57, 79, 125, 200));
		rect(0, 0, width, height);
		pop();
		push();
		textSize(72);
		text("WINNER", width/2, height/3);
		pop();
		text(name[1], width/2, height/2);
	}
}

function drawEyes(side, cx, cy, d) {
	if (side == "Left") {
		push();
		fill("white");
		circle(cx+80, cy-50-(d/5), d/4);
		circle(cx+40, cy-40-(d/5), d/2);
		pop();

		push();
		fill("black");
		circle(cx+85, cy-55-(d/5), d/12);
		circle(cx+25, cy-35-(d/5), d/5);
		pop();
	}
	if (side == "Right") {
		push();
		fill("white");
		circle(cx-80, cy-50-(d/5), d/4);
		circle(cx-40, cy-40-(d/5), d/3);
		pop();

		push();
		fill("black");
		circle(cx-85, cy-65-(d/5), d/12);
		circle(cx-25, cy-35-(d/5), d/4);
		pop();
	}
}

function drawBones(side, x, y, cx, cy){
	push();
	rectMode(CENTER);
	fill("black");
	if (side == "Left") {
		for (let i=1; i<4; i++) {
      let boneWidth = y/(15*i); 
      let boneHeight = y/(10*i); 
      let boneX = cx-20*i;
      let boneY = (cy-30)+10*i; 
      rect(boneX, boneY, boneWidth, boneHeight, 8); 
    }
    for (let i=1; i<4; i++) {
      let boneWidth = y/(15*i); 
      let boneHeight = y/(10*i); 
      let boneX = cx-20*i; 
      let boneY = cy+30-(5*i); 
      rect(boneX, boneY, boneWidth, boneHeight, 8); 
    }
	}
  if (side == "Right"){
		for (let i=1; i<4; i++) {
      let boneWidth = y/(15*i); 
      let boneHeight = y/(10*i); 
      let boneX = cx+20*i;
      let boneY = (cy-30)+10*i; 
      rect(boneX, boneY, boneWidth, boneHeight, 8); 
    }
    for (let i=1; i<4; i++) {
      let boneWidth = y/(15*i); 
      let boneHeight = y/(10*i); 
      let boneX = cx+20*i; 
      let boneY = cy+30-(5*i); 
      rect(boneX, boneY, boneWidth, boneHeight, 8); 
    }
		
	}
	pop();
}

function drawHat(x, y){
	push();
	fill(color(222, 100, 29));
	ellipse(x, y-60, 60, 25)
	beginShape();
	vertex(x-10, y-80);
	vertex(x+10, y-80);
	vertex(x+15, y-60);
	vertex(x-15, y-60);
	endShape();
	pop();
}


function healthBar() {
	let leftLerpFac = map(leftHealth, 0, 255, 1, 0);
	let leftColor = lerpColor(from, to, leftLerpFac);
	let rightLerpFac = map(rightHealth, 0, 255, 1, 0);
	let rightColor = lerpColor(from, to, rightLerpFac);

	push();
	fill(leftColor);
	let leftWidth = map(leftHealth, 0, 255, 0, 200);
	rect(40, 20, leftWidth, 15, 10);
	pop();

	push();
	fill(rightColor);
	let rightWidth = map(rightHealth, 0, 255, 0, 200);
	rect(400, 20, rightWidth, 15, 10);
	pop();
	
	//draw stroke
	push();
	noFill();
	strokeWeight(3);
	stroke("#d4cfbc");
	rect(40, 20, 200, 15, 10);
	rect(400, 20, 200, 15, 10);
	pop();
	
	//draw heart
	push();
	fill(leftColor);
	beginShape();
	bezier(40,15, 15,5, 20,30, 40,45);
	bezier(40,45, 60,30, 65,5, 40,15);
	endShape();
	pop();
	
	push();
	noFill();
	strokeWeight(3);
	stroke("#d4cfbc");
	beginShape();
	bezier(40,15, 15,5, 20,30, 40,45);
	bezier(40,45, 60,30, 65,5, 40,15);
	endShape();
	pop();
	
	push();
	fill(rightColor);
	beginShape();
	bezier(600,15, 575,5, 580,30, 600,45);
	bezier(600,45, 620,30, 625,5, 600,15);
	endShape();
	pop();
	
	push();
	noFill();
	strokeWeight(3);
	stroke("#d4cfbc");
	beginShape();
	bezier(600,15, 575,5, 580,30, 600,45);
	bezier(600,45, 620,30, 625,5, 600,15);
	endShape();
	pop();
}

function drawBlood(cx, cy) {
	for (let i=0; i<lenBloodArr; i++){
		 addDrop(bloodArr, cx, cy);
	}
	
}

function damage() {
	if (hands.length == 2) {
		let firstCX = hands[0].keypoints[INDEX_MCP].x;
		let firstCY = hands[0].keypoints[INDEX_MCP].y;
		let secCX = hands[1].keypoints[INDEX_MCP].x;
		let secCY = hands[1].keypoints[INDEX_MCP].y;

		let firstTX = hands[0].keypoints[THUMB_TIP].x;
		let firstTY = hands[0].keypoints[THUMB_TIP].y;
		let firstIX = hands[0].keypoints[INDEX_TIP].x;
		let firstIY = hands[0].keypoints[INDEX_TIP].y;
		let secTX = hands[1].keypoints[THUMB_TIP].x;
		let secTY = hands[1].keypoints[THUMB_TIP].y;
		let secIX = hands[1].keypoints[INDEX_TIP].x;
		let secIY = hands[1].keypoints[INDEX_TIP].y;
		let handDist = dist(firstCX, firstCY, secCX, secCY);
		let chomp0 = dist(firstTX, firstTY, firstIX, firstIY);
		let chomp1 = dist(secTX, secTY, secIX, secIY);
		if (handDist < 220) {
			if (chomp0 < 30 && isChomped0 == false) {
				if (hands[0].handedness == "Left") {
					rightHealth == max(0, rightHealth -= 10);
					if (rightHealth==0) isDefeated1 = true;
				}
				if (hands[0].handedness == "Right") {
					leftHealth == max(0, leftHealth -= 10);
					if (leftHealth==0) isDefeated0 = true;
				}
				drawBlood(secCX, secCY);
				isChomped0 = true;
			}
			
			if (chomp1 < 30 && isChomped1 == false) {
				if (hands[1].handedness == "Left") {
					rightHealth == max(0, rightHealth -= 10);
					if (rightHealth==0) isDefeated1 = true;
				}
				if (hands[1].handedness == "Right") {
					leftHealth == max(0, leftHealth -= 10);
					if (leftHealth==0) isDefeated0 = true;
				}
				drawBlood(firstCX, firstCY);
				isChomped1 = true;
			}
		}
		if (chomp0 >= 30){isChomped0 = false;}
		if (chomp1 >= 30){isChomped1 = false;}
		// drawBlood(secCX, secCY);
		// drawBlood(firstCX, firstCY);
	}
	
	if (leftHealth <= 0) {
		endGame("Right")
	}
	if (rightHealth <= 0) {
		endGame("Left");
	}
}

function getPacColor() {
	if (hands.length > 1) {
		let firstX = hands[0].keypoints[THUMB_TIP].x;
		let firstY = hands[0].keypoints[THUMB_TIP].y;
		let secX = hands[1].keypoints[THUMB_TIP].x;
		let secY = hands[1].keypoints[THUMB_TIP].y;
		let handDist = dist(firstX, firstY, secX, secY);
		let colorValue = map(handDist, 0, 640, 0, 225);
		let pacColor = color(255, 225-colorValue, 30);
		return pacColor;
	} else {
		return "beige"
	}
}

function drawPac() {
	let maxDistance = 100;
	let minDistance = 10;
	noStroke();

	let pacColor = getPacColor();
	fill(pacColor);

	if (hands.length > 0) {
		for (let i = 0; i < hands.length; i++) {
			let pacCenX = hands[i].keypoints[INDEX_MCP].x;
			let pacCenY = hands[i].keypoints[INDEX_MCP].y;
			let thumbX = hands[i].keypoints[THUMB_TIP].x;
			let thumbY = hands[i].keypoints[THUMB_TIP].y;
			let indexX = hands[i].keypoints[INDEX_TIP].x;
			let indexY = hands[i].keypoints[INDEX_TIP].y;
			let pinkyX = hands[i].keypoints[PINKY_TIP].x;
			let pinkyY = hands[i].keypoints[PINKY_TIP].y;
			let middleX = hands[i].keypoints[MIDDLE_TIP].x;
			let middleY = hands[i].keypoints[MIDDLE_TIP].y;

			let d = dist(thumbX, thumbY, indexX, indexY) - 5;
			if (hands[i].handedness == "Left") {
				drawName("Left", pacCenX, pacCenY);
				beginShape();
				vertex(pacCenX, pacCenY-50);
				bezierVertex(pacCenX-15, pacCenY-65, pacCenX-30, pacCenY-65, pacCenX-50, pacCenY-30);
				bezierVertex(pacCenX-75, pacCenY, pacCenX-15, pacCenY, pacCenX-100, pacCenY);
				endShape();
				beginShape();
				vertex(pacCenX-100, pacCenY);
				bezierVertex(pacCenX-110, pacCenY+40, pacCenX, pacCenY+50, pacCenX, pacCenY+50);
				vertex(pacCenX, pacCenY-50);
				endShape();
				
				let topAngle = map(d, 0, maxDistance, PI, 5 * PI / 6);
				let botAngle = map(d, 0, maxDistance, 0, PI / 6);
				let arcBot = botAngle;
				let arcTop = PI + topAngle;
				arc(pacCenX, pacCenY, 100, 100, arcBot, arcTop);
				drawEyes("Left", pacCenX, pacCenY, d);
				push();
				drawingContext.shadowBlur = 30;
				drawingContext.shadowColor = pacColor;
				drawTails("Left", pinkyX, pinkyY);
				drawBones("Left", middleX, middleY, pacCenX, pacCenY);
				pop();
				// drawHat(pacCenX, pacCenY);
			}
			if (hands[i].handedness == "Right") {
				drawName("Right", pacCenX, pacCenY);
				beginShape();
				vertex(pacCenX, pacCenY-50);
				bezierVertex(pacCenX+15, pacCenY-65, pacCenX+30, pacCenY-65, pacCenX+50, pacCenY-30);
				bezierVertex(pacCenX+75, pacCenY, pacCenX+15, pacCenY, pacCenX+100, pacCenY);
				endShape();
				beginShape();
				vertex(pacCenX+100, pacCenY);
				bezierVertex(pacCenX+110, pacCenY+40, pacCenX, pacCenY+50, pacCenX, pacCenY+50);
				vertex(pacCenX, pacCenY-50);
				endShape();

				let topAngle = map(d, 0, maxDistance, PI, 5 * PI / 6);
				let botAngle = map(d, 0, maxDistance, PI, 7 * PI / 6);
				let arcBot = botAngle;
				let arcTop = topAngle;
				arc(pacCenX, pacCenY, 100, 100, arcBot, arcTop);
				drawEyes("Right", pacCenX, pacCenY, d);
				push();
				drawingContext.shadowBlur = 30;
				drawingContext.shadowColor = pacColor;
				drawTails("Right", pinkyX, pinkyY);
				drawBones("Right", middleX, middleY, pacCenX, pacCenY);
				pop();
				// drawHat(pacCenX, pacCenY);
			}
		}
	}
}

//==============================================================
// DON'T CHANGE ANYTHING BELOW THIS LINE
// UNLESS YOU KNOW WHAT YOU ARE DOING. <3
//
//----------------------------
function initializeWebcamAndHandTracker() {
	// Create the webcam video, and start detecting hands:
	myWebcam = createCapture(VIDEO);
	myWebcam.size(640, 480).hide();
	myHandTracker.detectStart(myWebcam, gotHands);
}

//----------------------------
function drawWebcamVideo() {
	// Draw the webcam video
	push();
	if (trackerOptions.flipHorizontal) {
		translate(myWebcam.width, 0);
		scale(-1, 1);
	}
	tint(255, 255, 255, webcamAlpha);
	image(myWebcam, 0, 0, myWebcam.width, myWebcam.height);
	pop();
}

//----------------------------
function preload() {
	// Load the handpose model. 
	// Note the subtle API difference:
	// Use ml5.handpose for ml5.js v0.20.0
	// Use ml5.handPose for ml5.js v1.2.1
	myHandTracker = ml5.handpose(trackerOptions);
	font = loadFont('Silkscreen-Regular.ttf');
}

let avg = 0;

function gotHands(results) {
	// If fresh handpose data is received, store it.
	hands = results;
}

//----------------------------
// The following hand point index labels may be useful:
const WRIST = 0;
const THUMB_CMC = 1;
const THUMB_MCP = 2;
const THUMB_IP = 3;
const THUMB_TIP = 4;
const INDEX_MCP = 5;
const INDEX_PIP = 6;
const INDEX_DIP = 7;
const INDEX_TIP = 8;
const MIDDLE_MCP = 9;
const MIDDLE_PIP = 10;
const MIDDLE_DIP = 11;
const MIDDLE_TIP = 12;
const RING_MCP = 13;
const RING_PIP = 14;
const RING_DIP = 15;
const RING_TIP = 16;
const PINKY_MCP = 17;
const PINKY_PIP = 18;
const PINKY_DIP = 19;
const PINKY_TIP = 20;